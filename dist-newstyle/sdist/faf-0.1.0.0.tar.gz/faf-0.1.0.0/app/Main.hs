module Main where

import qualified Data.Text as Text

import Agent (Context (..), llmSingleTurnAgent)
import Control.Monad.Trans.State

ctx :: Context
ctx = Context {chats = []}

main :: IO ()
main = do
  (m, _) <- runStateT llmSingleTurnAgent ctx
  putStrLn 
