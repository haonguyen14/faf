{-# LANGUAGE DuplicateRecordFields #-}
{-# LANGUAGE NamedFieldPuns        #-}
{-# LANGUAGE OverloadedStrings     #-}
{-# LANGUAGE OverloadedLists       #-}

module Agent (Context (..), Chat, repeatAgent, llmSingleTurnAgent) where

import qualified Data.Text as Text
import qualified System.Environment as Environment

import Control.Monad.Trans.Class
import Control.Monad.Trans.State

import OpenAI.V1
import OpenAI.V1.Chat.Completions

newtype Context = Context {chats :: [Chat]}

type Chat = Text.Text

repeatAgent :: StateT Context IO Chat
repeatAgent = do
  ctx <- get
  case chats ctx of
    [] -> return $ Text.pack ""
    m : _ -> return m

llmCall :: [Chat] -> IO Chat
llmCall [] = return ""
llmCall (m : _) = do
  key <- Environment.getEnv "OPENAI_KEY"
  clientEnv <- getClientEnv "https://api.openai.com"

  let Methods { createChatCompletion } = makeMethods clientEnv (Text.pack key) Nothing Nothing

  ChatCompletionObject { choices } <- createChatCompletion _CreateChatCompletion
    {
      messages = [ User { name = Nothing, content = [ Text { text = m } ] } ],
      model = "gpt-4o-mini"
    }

  return $ foldr (Text.append . messageToContent . message) "" choices

llmSingleTurnAgent :: StateT Context IO Chat
llmSingleTurnAgent = do
  ctx <- get
  lift . llmCall . chats $ ctx